extends Sprite2D
@onready var animated_sprite_2d: AnimatedSprite2D = $"../AnimatedSprite2D"

func _ready() -> void:
	pass

func _process(delta: float) -> void:
	pass


func _on_body_entered(body: Node2D) -> void:
	animated_sprite_2d.animation = "collected"
# need to add sound effects 

#function increase_score()-> void:
	#
# handling the score
