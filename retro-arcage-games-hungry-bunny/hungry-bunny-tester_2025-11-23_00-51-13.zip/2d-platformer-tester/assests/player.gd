extends CharacterBody2D
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D

const SPEED = 300.0
const JUMP_VELOCITY = -800.0
const GRAVITY = 2100.0

func _physics_process(delta: float) -> void:
	# animation: idle / jumping
	if abs(velocity.x) > 1: 
		animated_sprite_2d.animation = "jumping"
	else:
		animated_sprite_2d.animation = "idle"

	# gravity
	if not is_on_floor():
		velocity.y += GRAVITY * delta

	# jump
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# horizontal movement
	var direction := Input.get_axis("left", "right")

	if direction != 0:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	# applying movement
	move_and_slide()

	# sprite flipping
	if direction > 0:
		animated_sprite_2d.flip_h = true
	elif direction < 0:
		animated_sprite_2d.flip_h = false
